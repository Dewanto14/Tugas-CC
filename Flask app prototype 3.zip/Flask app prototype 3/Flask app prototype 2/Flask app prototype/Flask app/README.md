semua file .py HARUS di jalanin pake pyton3 (ex: python3 init.py)

init.py di jalanin pertama supaya data.db nya kebikin ulang (kalo data.db engga ada/bermasalah run ulang aja init.py nya)

kalo data.db udah ada langsung run codeverse.py
flask secara default bakal ngebuka di http://127.0.0.1:5000
lu bisa buka admin page di http://127.0.0.1:5000/admin/123

html file nya pake syntax 'tinja2', bisa minta chatgpt ato bikin html biasa aja, ntar gw yg integrasi ke tinja2
titit c=====3